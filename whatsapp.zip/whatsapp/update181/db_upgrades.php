<?php 
#	Core database update fcodes
#	Do not modify this file
#	Version:  1.7.4
#	Release date: 2017-06-05
#   Add new changes above the old ones
global $server;
#v 1.7.4
mysqli_query($server,"ALTER TABLE `currencies` ADD `zeros` INT NOT NULL DEFAULT '2' AFTER `code`;");


#v1.7.3
mysqli_query($server,"UPDATE `paymentgateway_templates` SET `param1_label` = 'Publishable Key' WHERE `alias` = 'stripe';");
mysqli_query($server,"UPDATE `paymentgateway_templates` SET `param1_labe2` = 'Secret Key' WHERE `alias` = 'stripe';");


#v 1.7.0
mysqli_query($server,"CREATE TABLE `message_types` (
 `id` INT NOT NULL AUTO_INCREMENT ,
 `title` VARCHAR(300) NOT NULL , 
`alias` VARCHAR(300) NOT NULL , 
`enabled` INT NOT NULL DEFAULT '1' , 
`defaut_gateway` INT NOT NULL  DEFAULT '0',
`is_custom` INT NOT NULL  DEFAULT '1',
 PRIMARY KEY (`id`)
) ENGINE = InnoDB COMMENT = 'stores message types';");
mysqli_query($server,"ALTER TABLE `shortcodes` ADD `type` VARCHAR(444) NOT NULL DEFAULT 'sms' AFTER `resold`;");
mysqli_query($server,"ALTER TABLE `sms_gateways` ADD `group_id` INT NOT NULL DEFAULT '1' AFTER `base64_encode`;");
mysqli_query($server,"ALTER TABLE `sms_gateways` ADD `d_rate` VARCHAR(5055) NOT NULL DEFAULT '0' AFTER `group_id`;");


#v 1.6.0
//add custom fields tabloes
mysqli_query($server,"CREATE TABLE `customfields` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `field_type` varchar(333) NOT NULL DEFAULT 'Text Box',
  `required` varchar(33) NOT NULL DEFAULT 'No',
  `show_form` varchar(33) NOT NULL DEFAULT '0',
  `enabled` varchar(33) NOT NULL DEFAULT '1',
  `name` varchar(444) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
mysqli_query($server,"ALTER TABLE `customfields`  ADD PRIMARY KEY (`id`);");
mysqli_query($server,"ALTER TABLE `customfields`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;");

mysqli_query($server,"CREATE TABLE `customfield_values` (
  `id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `value` varchar(444) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;  ");
mysqli_query($server,"ALTER TABLE `customfield_values` ADD PRIMARY KEY (`id`); ");
mysqli_query($server,"ALTER TABLE `customfield_values` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT; ");
  

#	v 1.4.2
//add new settings field
saveSettings('sendRate',60,0);
//set label names for custom module
mysqli_query($server,"UPDATE `api_templates` SET `param1_label` = 'Parameter 1 Value' WHERE `alias` = 'custom';");
mysqli_query($server,"UPDATE `api_templates` SET `param2_label` = 'Parameter 2 Value' WHERE `alias` = 'custom';");
mysqli_query($server,"UPDATE `api_templates` SET `param3_label` = 'Parameter 3 Value' WHERE `alias` = 'custom';");
mysqli_query($server,"UPDATE `api_templates` SET `param4_label` = 'Parameter 4 Value' WHERE `alias` = 'custom';");
mysqli_query($server,"UPDATE `api_templates` SET `param5_label` = 'Parameter 5 Value' WHERE `alias` = 'custom';");

#  v 1.4.1
mysqli_query($server,"ALTER TABLE `smschat` DROP `id`;");
mysqli_query($server,"ALTER TABLE `smschat`  ADD `id` INT NOT NULL AUTO_INCREMENT  FIRST,  ADD   PRIMARY KEY  (`id`);");


#   Verson 1.4.0
//Alter scheduled message structure to add new features from 1.4.0
mysqli_query($server,"ALTER TABLE `scheduledmessages` ADD `repeats` VARCHAR(30) NOT NULL DEFAULT '0' AFTER `to_count`, ADD `day` VARCHAR(30) NOT NULL AFTER `repeats`;");
//Create structure for sms chat
mysqli_query($server,"CREATE TABLE `smschat` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `sender` varchar(30) NOT NULL,
  `receiver` varchar(30) NOT NULL,
  `message` varchar(666) NOT NULL,
  `date` varchar(44) NOT NULL,
  `sent` INT NOT NULL DEFAULT '0',
  `number` VARCHAR(44) NOT NULL,
  `seen` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");


#   Verson 1.3.2
//correct cron job instructions
mysqli_query($server,"DROP TABLE IF EXISTS `crons`;");
mysqli_query($server,"CREATE TABLE `crons` (
  `id` int(11) NOT NULL,
  `description` varchar(666) NOT NULL,
  `location` varchar(555) NOT NULL,
  `period` varchar(333) NOT NULL DEFAULT 'Once per day'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");

mysqli_query($server,"TRUNCATE TABLE `crons`;");
mysqli_query($server,"INSERT INTO `crons` (`id`, `description`, `location`, `period`) VALUES
(1, 'System Hour Cron', 'cronsH.php', 'Once per Hour'),
(2, 'System Minute Cron', 'crons.php', 'Once per Minute'),
(3, 'Infobip Gateway DLR Cron', 'smsapi/infobip/cron.php', 'Once per Minute');");
?>