<?php

class Services_Twilio_Rest_Trunking_Trunks extends Services_Twilio_TrunkingListResource {
  
}
