<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
	#	WhatsApp module for Sendroid Ultimate
	#	location: smsapi/whatsapp/index.php
	#	Developed by: Ynet Interactive
	#	Special thanks: Mr. White
*/
global $LANG;
global $configverssion_id;
global $configapp_version;
global $server;

$message_id = $THIS_MESSAGE_ID;
$userID = singleMessageData($THIS_MESSAGE_ID,'customer_id');
$resellerID = userData($userID,'reseller');
$gateway_id = $THIS_MESSAGE_GATEWAY;

$customer_id = singleMessageData($THIS_MESSAGE_ID,'customer_id');
$from = singleMessageData($THIS_MESSAGE_ID,'sender_id');
$to = singleMessageData($THIS_MESSAGE_ID,'recipient');
$message = singleMessageData($THIS_MESSAGE_ID,'message');
$type = singleMessageData($THIS_MESSAGE_ID,'type');
$duration = singleMessageData($THIS_MESSAGE_ID,'duration');
$country = singleMessageData($THIS_MESSAGE_ID,'country_id');
$pageCount = countPage($message,$type,$duration);
$cost = smsCost($to,$type,$country,$pageCount,$customer_id);
$media = singleMessageData($THIS_MESSAGE_ID,'media');
$type = singleMessageData($THIS_MESSAGE_ID,'type');

//gateway authentication stuffs		
$username = str_replace('+','',smsGatewayData($gateway_id,'username')); 
$password = smsGatewayData($gateway_id,'password'); 
$displayname = smsGatewayData($gateway_id,'param1_value'); 
if(empty($displayname)) $displayname = 'WhatsApp User';

require_once __DIR__.'/src/whatsprot.class.php'; 
$w = new WhatsProt($username, 0, $displayname, true); 
$w->connect();
$w->loginWithPassword($password);
 
$w->SendPresenceSubscription($target); 
$w->sendMessage($to,$message ); 

   $status = 'sent';
	mysqli_query($server, "UPDATE  `messagedetails` SET `status` = 'sent' WHERE `id` = '$message_id'");
	mysqli_query($server, "UPDATE  `messagedetails` SET `cost` = '$cost' WHERE `id` = '$message_id'");	
	mysqli_query($server, "UPDATE  `messagedetails` SET `dlr` = 'sent' WHERE `id` = '$message_id'");	
?>