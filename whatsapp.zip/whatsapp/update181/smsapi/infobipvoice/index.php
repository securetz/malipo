<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
	#	Infobip Voice module for Sendroid Ultimate
	#	location: smsapi/infobipvoice/index.php
	#	Developed by: Ynet Interactive
	#	Special thanks: Mr. White
*/
global $LANG;
global $configverssion_id;
global $configapp_version;
global $server;

$message_id = $THIS_MESSAGE_ID;
$userID = singleMessageData($THIS_MESSAGE_ID,'customer_id');
$resellerID = userData($userID,'reseller');
$gateway_id = $THIS_MESSAGE_GATEWAY;

$customer_id = singleMessageData($THIS_MESSAGE_ID,'customer_id');
$from = singleMessageData($THIS_MESSAGE_ID,'sender_id');
$to = singleMessageData($THIS_MESSAGE_ID,'recipient');
$message = singleMessageData($THIS_MESSAGE_ID,'message');
$type = singleMessageData($THIS_MESSAGE_ID,'type');
$duration = singleMessageData($THIS_MESSAGE_ID,'duration');
$country = singleMessageData($THIS_MESSAGE_ID,'country_id');
$duration = singleMessageData($THIS_MESSAGE_ID,'duration');
$media = singleMessageData($THIS_MESSAGE_ID,'media');
$pageCount = countPage($message,$type,$duration);
$cost = smsCost($to,$type,$country,$pageCount,$customer_id);
$cost = smsCost($to,$type,$country,$pageCount,$customer_id,$gateway_id);
		
$username = smsGatewayData($gateway_id,'username'); 
$password = smsGatewayData($gateway_id,'password'); 

$textMessage2 = urlencode($message);
$retry = array("minPeriod"=>30,
           	"maxPeriod" => 60,
            "maxCount" =>5);
$data = array("from" => "$from", 
			"to" => "$to", 
			"text" => "$message", 
			"record" => true,
			"retryCount" => 3,
			"retryPeriod" => 300,
			"callTimeout" => $duration,
			"retry" => $retry,
			"ringTimeout" => 45);
if(!empty($media)) {
$data = array("from" => "$from", 
			"to" => "$to", 
			"audioFileUrl" => "$media", 
			"record" => true,
			"retryCount" => 3,
			"retryPeriod" => 300,
			"callTimeout" => "$duration",
			"retry" => $retry,
			"ringTimeout" => 45);	
}
$data_string = json_encode($data);
$authenticate = base64_encode($username.':'.$password);
		
$ch = curl_init('https://api.infobip.com/tts/3/single');
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	'Content-Type: application/json',
	'authorization: Basic "'.$authenticate.'"',
	'Accept: application/json',
	'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);	
$response = curl_exec($ch);
curl_close($ch);			
if(!$response) {
	$status = 'Connection to Gateway Failed.';  //. curl_error($ch)
	mysqli_query($server, "UPDATE  `messagedetails` SET `status` = 'failed' WHERE `id` = '$message_id'");
	mysqli_query($server, "UPDATE  `messagedetails` SET `cost` = '0' WHERE `id` = '$message_id'");	
	mysqli_query($server, "UPDATE  `messagedetails` SET `dlr` = 'failed' WHERE `id` = '$message_id'");	
	mysqli_query($server, "UPDATE  `messagedetails` SET `notice` = '$status' WHERE `id` = '$message_id'");
} else {
	if((stripos(strtoupper($response),'messageId') !== false)) {
	   $status = 'sent';
		$responseBody = json_decode($response);
		$messages = $responseBody->messages;        
		foreach ($messages as $msg) {
			$gatewayID = $msg->messageId ; 
		}
		mysqli_query($server, "UPDATE  `messagedetails` SET `status` = 'sent' WHERE `id` = '$message_id'");
		mysqli_query($server, "UPDATE  `messagedetails` SET `cost` = '$cost' WHERE `id` = '$message_id'");	
		mysqli_query($server, "UPDATE  `messagedetails` SET `dlr` = 'sent' WHERE `id` = '$message_id'");	
		mysqli_query($server, "UPDATE  `messagedetails` SET `api_id` = '$gatewayID' WHERE `id` = '$message_id'");
   } else {
	  $status = $response;
	  $status = mysqli_real_escape_string($server,$status);
	  mysqli_query($server, "UPDATE  `messagedetails` SET `status` = 'failed' WHERE `id` = '$message_id'");
	  mysqli_query($server, "UPDATE  `messagedetails` SET `cost` = '0' WHERE `id` = '$message_id'");	
	  mysqli_query($server, "UPDATE  `messagedetails` SET `dlr` = 'failed' WHERE `id` = '$message_id'");	
	  mysqli_query($server, "UPDATE  `messagedetails` SET `notice` = '$status' WHERE `id` = '$message_id'");
   }
}
?>